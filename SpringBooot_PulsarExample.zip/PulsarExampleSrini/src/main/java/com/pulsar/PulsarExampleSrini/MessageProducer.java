package com.pulsar.PulsarExampleSrini;

import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.apache.pulsar.client.api.PulsarClientException;
import org.springframework.pulsar.core.PulsarTemplate;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class MessageProducer {

    @NonNull private PulsarTemplate<CustomMessage> pulsarTemplate;  
    public void sendMessage(CustomMessage message) {
        try {
            pulsarTemplate.send("training1", message);
        } catch (PulsarClientException e) {
            throw new RuntimeException(e);
        }
    }
}