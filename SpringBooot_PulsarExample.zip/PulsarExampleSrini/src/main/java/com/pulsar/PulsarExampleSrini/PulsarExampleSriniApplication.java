package com.pulsar.PulsarExampleSrini;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import lombok.RequiredArgsConstructor;
@SpringBootApplication
@RequiredArgsConstructor
public class PulsarExampleSriniApplication implements CommandLineRunner{
	@Autowired
	 private MessageProducer messageProducer;

	public static void main(String[] args) {
		SpringApplication.run(PulsarExampleSriniApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		System.out.println("Start sending message using apache pulsar");
		messageProducer.sendMessage(new CustomMessage(1, "Hello Pulsar", System.currentTimeMillis()));
	}
}
