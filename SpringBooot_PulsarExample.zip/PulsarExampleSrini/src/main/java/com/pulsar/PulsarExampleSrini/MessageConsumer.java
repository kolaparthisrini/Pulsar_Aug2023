package com.pulsar.PulsarExampleSrini;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.pulsar.common.schema.SchemaType;
import org.springframework.pulsar.annotation.PulsarListener;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class MessageConsumer {

    @PulsarListener(subscriptionName = "training1", topics = "training1", schemaType = SchemaType.JSON)
    public void consumeMessage(CustomMessage message) {
        System.out.println("Message Received: id = {}, body={}, createdAt={}  ");
        System.out.println(message.getBody() );
    }
}