package com.pulsar.PulsarExampleSrini;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PulsarExampleSriniApplicationTests {

	@Test
	void contextLoads() {
	}

}
